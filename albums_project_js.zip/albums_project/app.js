import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { openDb } from './database.js';  // Az adatbázis kezelése

const app = express();
app.use(express.json());

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Statikus fájlok kiszolgálása (frontend fájlok)
app.use(express.static(path.join(__dirname, 'public')));

// Adatbázis inicializálása
async function initializeDatabase() {
    const db = await openDb();
    await db.exec(`
        CREATE TABLE IF NOT EXISTS albums (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            zenekar TEXT,
            cim TEXT,
            ev INTEGER,
            mufaj TEXT
        )
    `);
    const existingAlbums = await db.all('SELECT * FROM albums');
    if (existingAlbums.length === 0) {
        // Ha üres az adatbázis, alapadatokat töltünk fel
        await db.exec(`
            INSERT INTO albums (zenekar, cim, ev, mufaj) VALUES
            ('Travis Scott', 'ASTROWORLD', 2018, 'Hip-Hop'),
            ('Travis Scott', 'Rodeo', 2015, 'Hip-Hop'),
            ('Travis Scott', 'Utopia', 2023, 'Hip-Hop'),
            ('Playboi Carti', 'Die Lit', 2018, 'Trap'),
            ('Playboi Carti', 'Whole Lotta Red', 2020, 'Trap'),
            ('Playboi Carti', 'Playboi Carti', 2017, 'Trap'),
            ('Future', 'DS2', 2015, 'Trap'),
            ('Future', 'HNDRXX', 2017, 'R&B / Trap'),
            ('Future', 'High Off Life', 2020, 'Trap'),
            ('Future', 'I NEVER LIKED YOU', 2022, 'Trap')
        `);
    }
}

initializeDatabase();

// Albumok listázása, opcionális keresési paraméterrel
app.get('/albums', async (req, res) => {
    const db = await openDb();
    const searchQuery = req.query.search ? req.query.search.toLowerCase() : '';
    let albums;

    if (searchQuery) {
        albums = await db.all('SELECT * FROM albums WHERE LOWER(cim) LIKE ?', `%${searchQuery}%`);
    } else {
        albums = await db.all('SELECT * FROM albums');
    }

    res.status(200).json(albums);
});

// Egy album lekérése
app.get('/albums/:id', async (req, res) => {
    const db = await openDb();
    const album = await db.get('SELECT * FROM albums WHERE id = ?', req.params.id);
    if (!album) {
        return res.status(404).json({ message: 'Album nem található' });
    }
    res.status(200).json(album);
});

// Új album hozzáadása
app.post('/albums', async (req, res) => {
    const { zenekar, cim, ev, mufaj } = req.body;

    // Ellenőrizzük, hogy minden szükséges adat megvan-e
    if (!zenekar || !cim || !ev || !mufaj) {
        return res.status(400).json({ message: 'Hiányzó adatok' });
    }

    const db = await openDb();

    // Ellenőrizzük, hogy létezik-e már ugyanilyen album
    const existingAlbum = await db.get('SELECT * FROM albums WHERE zenekar = ? AND cim = ? AND ev = ?', zenekar, cim, ev);
    if (existingAlbum) {
        return res.status(409).json({ message: 'Ez az album már létezik!' });  // 409: Confict - ütközés
    }

    // Ha nem létezik, hozzáadjuk az albumot
    const result = await db.run('INSERT INTO albums (zenekar, cim, ev, mufaj) VALUES (?, ?, ?, ?)', zenekar, cim, ev, mufaj);
    res.status(201).json({ id: result.lastID, zenekar, cim, ev, mufaj });
});

// Album módosítása
app.put('/albums/:id', async (req, res) => {
    const { zenekar, cim, ev, mufaj } = req.body;
    const db = await openDb();
    const album = await db.get('SELECT * FROM albums WHERE id = ?', req.params.id);
    if (!album) {
        return res.status(404).json({ message: 'Album nem található' });
    }
    await db.run('UPDATE albums SET zenekar = ?, cim = ?, ev = ?, mufaj = ? WHERE id = ?', zenekar, cim, ev, mufaj, req.params.id);
    res.status(200).json({ id: req.params.id, zenekar, cim, ev, mufaj });
});

// Album törlése
app.delete('/albums/:id', async (req, res) => {
    const db = await openDb();
    const album = await db.get('SELECT * FROM albums WHERE id = ?', req.params.id);
    if (!album) {
        return res.status(404).json({ message: 'Album nem található' });
    }
    await db.run('DELETE FROM albums WHERE id = ?', req.params.id);
    res.status(200).json({ message: 'Album törölve' });
});

// Hiba kezelése
app.use((err, req, res, next) => {
    console.error(err);
    res.status(500).json({ message: `Szerverhiba: ${err.message}` });
});

const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Szerver fut a ${PORT}-es porton`);
});
