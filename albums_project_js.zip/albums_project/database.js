import sqlite3 from 'sqlite3';
import { open } from 'sqlite';
import path from 'path';

// Adatbázis megnyitása
export const openDb = () => {
    return open({
        filename: path.join('data', 'albums.db'),  // Az adatbázis fájl elérési útja
        driver: sqlite3.Database
    });
};
