// Albumok lekérése és megjelenítése
function fetchAlbums() {
    const searchQuery = document.getElementById('search').value;
    const url = searchQuery ? `/albums?search=${searchQuery}` : '/albums';

    fetch(url)
        .then(response => response.json())
        .then(data => {
            const albumokLista = document.getElementById('albumok-lista');
            albumokLista.innerHTML = '';

            data.forEach(album => {
                const card = document.createElement('div');
                card.className = 'album-card';
                card.innerHTML = `
                    <h3>${album.zenekar}</h3>
                    <p><strong>${album.cim}</strong> (${album.ev})</p>
                    <p><em>${album.mufaj}</em></p>
                    <div class="card-buttons">
                        <button class="edit" onclick="editAlbum(${album.id})">Szerkesztés</button>
                        <button class="delete" onclick="deleteAlbum(${album.id})">Törlés</button>
                    </div>
                `;
                albumokLista.appendChild(card);
            });
        })
        .catch(error => {
            alert('Hiba történt az albumok lekérésekor');
            console.error(error);
        });
}

// Album hozzáadása
document.getElementById('add-album-form').addEventListener('submit', function (event) {
    event.preventDefault();
    const zenekar = document.getElementById('zenekar').value;
    const cim = document.getElementById('cim').value;
    const ev = document.getElementById('ev').value;
    const mufaj = document.getElementById('mufaj').value;

    fetch('/albums', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ zenekar, cim, ev, mufaj })
    })
        .then(response => {
            if (!response.ok) {
                return response.json().then(data => { throw new Error(data.message); });
            }
            return response.json();
        })
        .then(data => {
            alert('Album hozzáadva!');
            fetchAlbums();
            document.getElementById('add-album-form').reset();
        })
        .catch(error => {
            alert(`Hiba történt az album hozzáadásakor: ${error.message}`);
        });
});

// Album törlés
function deleteAlbum(id) {
    if (confirm("Biztosan törölni szeretnéd ezt az albumot?")) {
        fetch(`/albums/${id}`, {
            method: 'DELETE',
        })
            .then(response => {
                if (!response.ok) {
                    return response.json().then(data => { throw new Error(data.message); });
                }
                return response.json();
            })
            .then(data => {
                alert('Album törölve!');
                fetchAlbums();
            })
            .catch(error => {
                alert(`Hiba történt az album törlésénél: ${error.message}`);
            });
    }
}

// Album szerkesztés
function editAlbum(id) {
    const zenekar = prompt("Új zenekar neve:");
    const cim = prompt("Új album címe:");
    const ev = prompt("Új kiadás éve:");
    const mufaj = prompt("Új műfaj:");

    if (zenekar && cim && ev && mufaj) {
        fetch(`/albums/${id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ zenekar, cim, ev, mufaj })
        })
            .then(response => {
                if (!response.ok) {
                    return response.json().then(data => { throw new Error(data.message); });
                }
                return response.json();
            })
            .then(data => {
                alert('Album módosítva!');
                fetchAlbums();
            })
            .catch(error => {
                alert(`Hiba történt az album módosításakor: ${error.message}`);
            });
    }
}

// Oldal betöltésekor azonnal betölti az albumokat
fetchAlbums();
